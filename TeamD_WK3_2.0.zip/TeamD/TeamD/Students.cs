﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 1/30/2017
//  Description : This is the form and the controls for Student addition
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamD
{
    public partial class Students : Form
    {
        public Students()
        {
            InitializeComponent();
        }
        // Click event that adds the entered student information to the Students.txt file
        private void addStudentsButton_Click(object sender, EventArgs e)
        {
            string studentInfo = firstName.Text + "," + lastName.Text + "," + studentId.Text + "," + address.Text + "," + phoneNumber.Text + "," + email.Text + 
                "," + degreeProgram.Text + "\r\n";
            FileWorker fileWorker = new FileWorker();
            fileWorker.SaveFile("Students.txt",studentInfo);
            ClearTextBoxes();
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }
    }
}
