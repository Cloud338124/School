﻿////////////////////////////////
//  Author : Kevin Hicks
//  Date : 2/6/2017
//  Description : Class for creating student objects that contain the names and grades of the students froma a file
///////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grades
{
    public class Student
    {
        // Declares the name and grade variables for the student clas
        public string name {get; set;}
        public int grade { get; set; }
        // Get methods for both the grades and the names
        public int getGrade()
        {
            return this.grade;
        }
        public string getName()
        {
            return this.name;
        }
    }
    
}
