﻿namespace Grades
{
    partial class Grades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.studentsDataGrid = new System.Windows.Forms.DataGridView();
            this.loadFile = new System.Windows.Forms.Button();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classAverageLabel = new System.Windows.Forms.Label();
            this.highestGradeLabel = new System.Windows.Forms.Label();
            this.classAverageResult = new System.Windows.Forms.Label();
            this.highestGradeResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // studentsDataGrid
            // 
            this.studentsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentsDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.grade});
            this.studentsDataGrid.Location = new System.Drawing.Point(12, 3);
            this.studentsDataGrid.Name = "studentsDataGrid";
            this.studentsDataGrid.Size = new System.Drawing.Size(244, 361);
            this.studentsDataGrid.TabIndex = 0;
            // 
            // loadFile
            // 
            this.loadFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadFile.Location = new System.Drawing.Point(12, 370);
            this.loadFile.Name = "loadFile";
            this.loadFile.Size = new System.Drawing.Size(116, 30);
            this.loadFile.TabIndex = 1;
            this.loadFile.Text = "Load File";
            this.loadFile.UseVisualStyleBackColor = true;
            this.loadFile.Click += new System.EventHandler(this.loadFile_Click);
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // grade
            // 
            this.grade.DataPropertyName = "grade";
            this.grade.HeaderText = "Grade";
            this.grade.Name = "grade";
            this.grade.ReadOnly = true;
            // 
            // classAverageLabel
            // 
            this.classAverageLabel.AutoSize = true;
            this.classAverageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classAverageLabel.Location = new System.Drawing.Point(262, 9);
            this.classAverageLabel.Name = "classAverageLabel";
            this.classAverageLabel.Size = new System.Drawing.Size(165, 25);
            this.classAverageLabel.TabIndex = 2;
            this.classAverageLabel.Text = "Class Average";
            // 
            // highestGradeLabel
            // 
            this.highestGradeLabel.AutoSize = true;
            this.highestGradeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highestGradeLabel.Location = new System.Drawing.Point(262, 94);
            this.highestGradeLabel.Name = "highestGradeLabel";
            this.highestGradeLabel.Size = new System.Drawing.Size(352, 25);
            this.highestGradeLabel.TabIndex = 3;
            this.highestGradeLabel.Text = "Student With The Highest Grade";
            // 
            // classAverageResult
            // 
            this.classAverageResult.AutoSize = true;
            this.classAverageResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classAverageResult.ForeColor = System.Drawing.Color.Red;
            this.classAverageResult.Location = new System.Drawing.Point(263, 49);
            this.classAverageResult.Name = "classAverageResult";
            this.classAverageResult.Size = new System.Drawing.Size(151, 24);
            this.classAverageResult.TabIndex = 4;
            this.classAverageResult.Text = "Average Grade";
            this.classAverageResult.Visible = false;
            // 
            // highestGradeResult
            // 
            this.highestGradeResult.AutoSize = true;
            this.highestGradeResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highestGradeResult.ForeColor = System.Drawing.Color.Red;
            this.highestGradeResult.Location = new System.Drawing.Point(263, 136);
            this.highestGradeResult.Name = "highestGradeResult";
            this.highestGradeResult.Size = new System.Drawing.Size(132, 24);
            this.highestGradeResult.TabIndex = 5;
            this.highestGradeResult.Text = "Higest Grade";
            this.highestGradeResult.Visible = false;
            // 
            // Grades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 412);
            this.Controls.Add(this.highestGradeResult);
            this.Controls.Add(this.classAverageResult);
            this.Controls.Add(this.highestGradeLabel);
            this.Controls.Add(this.classAverageLabel);
            this.Controls.Add(this.loadFile);
            this.Controls.Add(this.studentsDataGrid);
            this.Name = "Grades";
            this.Text = "Grades";
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView studentsDataGrid;
        private System.Windows.Forms.Button loadFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn grade;
        private System.Windows.Forms.Label classAverageLabel;
        private System.Windows.Forms.Label highestGradeLabel;
        private System.Windows.Forms.Label classAverageResult;
        private System.Windows.Forms.Label highestGradeResult;

    }
}

