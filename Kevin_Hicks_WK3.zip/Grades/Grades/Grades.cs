﻿////////////////////////////////
//  Author : Kevin Hicks
//  Date : 2/6/2017
//  Description : Reads a file that contains a list of students and their grades, then outputs that information to a list that is bound to a table,
//  and then calculates the average grade and finds the name and grade of the highest grade in the class63
///////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grades
{
    public partial class Grades : Form
    {
        // Sets the filePath including the file name and instantiates tht StreameReader class so that the file can be read later
        public static string filePath = "Students.txt";
        StreamReader file = new StreamReader(filePath);
        // Creates a binding list of Student objects so that we can store the students and manipulate them later.
        BindingList <Student> students = new BindingList <Student>();
        
        public Grades()
        {
            InitializeComponent();
            // Binds the students list to the the studentsDataGrid table
            studentsDataGrid.DataSource = students;            
        }
        // Click event that reads the file to Student objects and stores them in the students list, then calculates the average grade and displays the highest grade
        // in the class
        private void loadFile_Click(object sender, EventArgs e)
        {

            string FileLine;                                    // Variable for storing the lines from the file reader
            string[] studentInfo;                               // Array for storing the info that we read from the file. Used to split the name string from the grade
            double averageTotal = 0;                            // Holds the running total of all grades that we can use to get the average grade
            List<Student> highestGrade = new List<Student>();   // List object that we use to store the sorted IEnumerables in to get the highest grade in the class

            try
            {
                // Reads the file, line by line, as long as there is a new line available
                while ((FileLine = file.ReadLine()) != null)
                {
                    // Splits the line into 2 indices so that they can be assigned to the name and grade properties of the student objects 
                    studentInfo = FileLine.Split(',');
                    students.Add(new Student() { name = studentInfo[0], grade = int.Parse(studentInfo[1]) });
                    // Calculates the running total of all grade values for averaging
                    averageTotal = averageTotal + double.Parse(studentInfo[1]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
            // Calculates the class average and outputs it to the proper label in the form, and then unhides the label
            classAverageResult.Text = "The Average Grade is " + (averageTotal / students.Count).ToString();
            classAverageResult.Visible = true;
            // Sorts the BindingList into the highestGrade List and then outputs the first value as to the proper label and unhides the label
            highestGrade = students.OrderByDescending(stnts => stnts.grade).ToList();
            highestGradeResult.Text = highestGrade[0].getName() +" with a " + highestGrade[0].getGrade().ToString();
            highestGradeResult.Visible = true;
        }  
      
    }
}
