﻿namespace TeamD
{
    partial class CoursesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFactultyID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCourseCred = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCourseLoc = new System.Windows.Forms.TextBox();
            this.stuIDn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lable3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lable1 = new System.Windows.Forms.Label();
            this.lblCourses = new System.Windows.Forms.Label();
            this.btnAddCourses = new System.Windows.Forms.Button();
            this.txtCourseStart = new System.Windows.Forms.DateTimePicker();
            this.txtCourseEnd = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.coursed = new System.Windows.Forms.TextBox();
            this.coursen = new System.Windows.Forms.TextBox();
            this.stuName = new System.Windows.Forms.ComboBox();
            this.couList = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // txtFactultyID
            // 
            this.txtFactultyID.Location = new System.Drawing.Point(116, 249);
            this.txtFactultyID.Name = "txtFactultyID";
            this.txtFactultyID.Size = new System.Drawing.Size(400, 20);
            this.txtFactultyID.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 252);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Faculty ID#:";
            // 
            // txtCourseCred
            // 
            this.txtCourseCred.Location = new System.Drawing.Point(116, 223);
            this.txtCourseCred.Name = "txtCourseCred";
            this.txtCourseCred.Size = new System.Drawing.Size(400, 20);
            this.txtCourseCred.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Course Credits:";
            // 
            // txtCourseLoc
            // 
            this.txtCourseLoc.Location = new System.Drawing.Point(116, 197);
            this.txtCourseLoc.Name = "txtCourseLoc";
            this.txtCourseLoc.Size = new System.Drawing.Size(400, 20);
            this.txtCourseLoc.TabIndex = 7;
            // 
            // stuIDn
            // 
            this.stuIDn.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.stuIDn.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.stuIDn.Location = new System.Drawing.Point(116, 67);
            this.stuIDn.Name = "stuIDn";
            this.stuIDn.Size = new System.Drawing.Size(400, 20);
            this.stuIDn.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Course Location:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "End Date:";
            // 
            // lable3
            // 
            this.lable3.AutoSize = true;
            this.lable3.Location = new System.Drawing.Point(12, 151);
            this.lable3.Name = "lable3";
            this.lable3.Size = new System.Drawing.Size(58, 13);
            this.lable3.TabIndex = 0;
            this.lable3.Text = "Start Date:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Student ID#";
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Location = new System.Drawing.Point(12, 44);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(78, 13);
            this.lable1.TabIndex = 0;
            this.lable1.Text = "Student Name:";
            // 
            // lblCourses
            // 
            this.lblCourses.AutoSize = true;
            this.lblCourses.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourses.Location = new System.Drawing.Point(4, 3);
            this.lblCourses.Name = "lblCourses";
            this.lblCourses.Size = new System.Drawing.Size(274, 31);
            this.lblCourses.TabIndex = 0;
            this.lblCourses.Text = "Course Registration";
            // 
            // btnAddCourses
            // 
            this.btnAddCourses.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddCourses.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCourses.Location = new System.Drawing.Point(12, 562);
            this.btnAddCourses.Name = "btnAddCourses";
            this.btnAddCourses.Size = new System.Drawing.Size(75, 23);
            this.btnAddCourses.TabIndex = 10;
            this.btnAddCourses.Text = "Add";
            this.btnAddCourses.UseVisualStyleBackColor = true;
            this.btnAddCourses.Click += new System.EventHandler(this.btnAddCourses_Click_1);
            // 
            // txtCourseStart
            // 
            this.txtCourseStart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtCourseStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCourseStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtCourseStart.Location = new System.Drawing.Point(116, 145);
            this.txtCourseStart.MinDate = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            this.txtCourseStart.Name = "txtCourseStart";
            this.txtCourseStart.Size = new System.Drawing.Size(400, 20);
            this.txtCourseStart.TabIndex = 5;
            this.txtCourseStart.Value = new System.DateTime(2017, 2, 14, 0, 0, 0, 0);
            // 
            // txtCourseEnd
            // 
            this.txtCourseEnd.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtCourseEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCourseEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtCourseEnd.Location = new System.Drawing.Point(116, 171);
            this.txtCourseEnd.MinDate = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            this.txtCourseEnd.Name = "txtCourseEnd";
            this.txtCourseEnd.Size = new System.Drawing.Size(400, 20);
            this.txtCourseEnd.TabIndex = 6;
            this.txtCourseEnd.Value = new System.DateTime(2017, 2, 14, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Course Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Course Description:";
            // 
            // coursed
            // 
            this.coursed.Location = new System.Drawing.Point(116, 119);
            this.coursed.Name = "coursed";
            this.coursed.Size = new System.Drawing.Size(400, 20);
            this.coursed.TabIndex = 4;
            // 
            // coursen
            // 
            this.coursen.Location = new System.Drawing.Point(116, 93);
            this.coursen.Name = "coursen";
            this.coursen.Size = new System.Drawing.Size(400, 20);
            this.coursen.TabIndex = 3;
            // 
            // stuName
            // 
            this.stuName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.stuName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.stuName.FormattingEnabled = true;
            this.stuName.Location = new System.Drawing.Point(116, 40);
            this.stuName.Name = "stuName";
            this.stuName.Size = new System.Drawing.Size(400, 21);
            this.stuName.TabIndex = 1;
            // 
            // couList
            // 
            this.couList.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.couList.AutoArrange = false;
            this.couList.BackColor = System.Drawing.Color.White;
            this.couList.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.couList.Location = new System.Drawing.Point(522, 40);
            this.couList.Name = "couList";
            this.couList.Size = new System.Drawing.Size(660, 544);
            this.couList.TabIndex = 11;
            this.couList.UseCompatibleStateImageBehavior = false;
            this.couList.View = System.Windows.Forms.View.Details;
            // 
            // CoursesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 597);
            this.Controls.Add(this.couList);
            this.Controls.Add(this.stuName);
            this.Controls.Add(this.txtCourseEnd);
            this.Controls.Add(this.txtCourseStart);
            this.Controls.Add(this.btnAddCourses);
            this.Controls.Add(this.coursen);
            this.Controls.Add(this.txtFactultyID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCourseCred);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCourseLoc);
            this.Controls.Add(this.coursed);
            this.Controls.Add(this.stuIDn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lable3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lable1);
            this.Controls.Add(this.lblCourses);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CoursesForm";
            this.Text = "Courses";
            this.Load += new System.EventHandler(this.CoursesForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFactultyID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCourseCred;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCourseLoc;
        private System.Windows.Forms.TextBox stuIDn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lable3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label lblCourses;
        private System.Windows.Forms.Button btnAddCourses;
        private System.Windows.Forms.DateTimePicker txtCourseStart;
        private System.Windows.Forms.DateTimePicker txtCourseEnd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox coursed;
        private System.Windows.Forms.TextBox coursen;
        private System.Windows.Forms.ComboBox stuName;
        public System.Windows.Forms.ListView couList;
    }
}