﻿///////////////////////
//  Author : Kevin Hicks, Robert Ford, Amber Capehart, Jerry Merten
//  Date : 2/5/2017
//  Description : Class for working with files. Reads file from txt file in CSV format to array. Writes from array to txt files in CSV format
///////////////////////
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamD
{
    class FileWorker
    {
        // Method for reading the students file that is in CSV format and returning a list of student objects
        public List<Student> ReadStudentsFile()
        {          
            StreamReader studentsFile = new StreamReader("Students.txt");           
            string currentLine;
            List<Student> studentList = new List<Student>();            
            try
            {
                while ((currentLine = studentsFile.ReadLine()) != null)
                {
                    string[] studentValues = currentLine.Split(',');
                    studentList.Add(new Student()
                    {
                        firstName = studentValues[0],
                        lastName = studentValues[1],
                        studentId = int.Parse(studentValues[2]),
                        address = studentValues[3],
                        phoneNumber = studentValues[4],
                        emailAddress = studentValues[5],
                        degreeProgram = studentValues[6]
                    });

                }
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
            
            return studentList;
        }
        // Method for reading the faculty file that is in CSV format and returning a list of student objects
        public List<Faculty> ReadFacultyFile()
        {
            StreamReader facultyFile = new StreamReader("Faculty.txt");
            string currentLine;
            List<Faculty> facultyList = new List<Faculty>();
            try
            {
                while ((currentLine = facultyFile.ReadLine()) != null)
                {
                    string[] facultyValues = currentLine.Split(',');
                    facultyList.Add(new Faculty()
                    {
                        firstName = facultyValues[0],
                        lastName = facultyValues[1],
                        facultyId = int.Parse(facultyValues[2]),
                        address = facultyValues[3],
                        phoneNumber = facultyValues[4],
                        emailAddress = facultyValues[5],
                        className = facultyValues[6],
                    });
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }

            return facultyList;
        }
        public List<Course> ReadCoursesFile()
        {
            StreamReader courseFile = new StreamReader("Courses.txt");
            string currentLine;
            List<Course> coursesList = new List<Course>();
            try
            {
                while ((currentLine = courseFile.ReadLine()) != null)
                {
                    string[] courseValues = currentLine.Split(',');
                    coursesList.Add(new Course()
                    {
                        courseNumber = int.Parse(courseValues[0]),
                        description = courseValues[1],
                        startDate = courseValues[2],
                        endDate = courseValues[3],
                        courseLocation = courseValues[4],
                        courseCredits = int.Parse(courseValues[5]),
                        factultyId = int.Parse(courseValues[6])
                    });
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message + error.StackTrace);
            }

            return coursesList;
        }
        // Writes a string to a new line in a file. The string should be in CSV format
        public void SaveFile(string filePath, string line)
        {            
            File.AppendAllText(filePath, line);
        }
    }
}
