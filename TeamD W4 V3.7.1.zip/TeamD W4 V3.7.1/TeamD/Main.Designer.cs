﻿namespace TeamD
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.students = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.faculty = new System.Windows.Forms.ToolStripMenuItem();
            this.addFaculty = new System.Windows.Forms.ToolStripMenuItem();
            this.courses = new System.Windows.Forms.ToolStripMenuItem();
            this.addCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.registration = new System.Windows.Forms.ToolStripMenuItem();
            this.printReport = new System.Windows.Forms.ToolStripMenuItem();
            this.registerCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exitApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel = new System.Windows.Forms.Panel();
            this.commonActionsLabel = new System.Windows.Forms.Label();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.addCoursesLabel = new System.Windows.Forms.Label();
            this.addFacultyLabel = new System.Windows.Forms.Label();
            this.addStudentsLabel = new System.Windows.Forms.Label();
            this.registerClassesIcon = new System.Windows.Forms.PictureBox();
            this.addFacultyIcon = new System.Windows.Forms.PictureBox();
            this.addCoursesIcon = new System.Windows.Forms.PictureBox();
            this.addStudentsIcon = new System.Windows.Forms.PictureBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenu.SuspendLayout();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.registerClassesIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addFacultyIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addCoursesIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addStudentsIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.students,
            this.faculty,
            this.courses,
            this.registration,
            this.exitMenu});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mainMenu.Size = new System.Drawing.Size(1183, 24);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "menuStrip1";
            this.mainMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.mainMenu_ItemClicked);
            // 
            // students
            // 
            this.students.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudents});
            this.students.Name = "students";
            this.students.Size = new System.Drawing.Size(65, 20);
            this.students.Text = "Students";
            // 
            // addStudents
            // 
            this.addStudents.Name = "addStudents";
            this.addStudents.Size = new System.Drawing.Size(96, 22);
            this.addStudents.Text = "Add";
            this.addStudents.Click += new System.EventHandler(this.addStudents_Click);
            // 
            // faculty
            // 
            this.faculty.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addFaculty});
            this.faculty.Name = "faculty";
            this.faculty.Size = new System.Drawing.Size(57, 20);
            this.faculty.Text = "Faculty";
            // 
            // addFaculty
            // 
            this.addFaculty.Name = "addFaculty";
            this.addFaculty.Size = new System.Drawing.Size(96, 22);
            this.addFaculty.Text = "Add";
            this.addFaculty.Click += new System.EventHandler(this.addFaculty_Click);
            // 
            // courses
            // 
            this.courses.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCourses});
            this.courses.Name = "courses";
            this.courses.Size = new System.Drawing.Size(61, 20);
            this.courses.Text = "Courses";
            // 
            // addCourses
            // 
            this.addCourses.Name = "addCourses";
            this.addCourses.Size = new System.Drawing.Size(96, 22);
            this.addCourses.Text = "Add";
            this.addCourses.Click += new System.EventHandler(this.addCourses_Click);
            // 
            // registration
            // 
            this.registration.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printReport,
            this.registerCourses});
            this.registration.Name = "registration";
            this.registration.Size = new System.Drawing.Size(82, 20);
            this.registration.Text = "Registration";
            // 
            // printReport
            // 
            this.printReport.Name = "printReport";
            this.printReport.Size = new System.Drawing.Size(223, 22);
            this.printReport.Text = "Print Report";
            this.printReport.Click += new System.EventHandler(this.printReport_Click);
            // 
            // registerCourses
            // 
            this.registerCourses.Name = "registerCourses";
            this.registerCourses.Size = new System.Drawing.Size(223, 22);
            this.registerCourses.Text = "Manage Course Registration";
            this.registerCourses.Click += new System.EventHandler(this.registration_Click);
            // 
            // exitMenu
            // 
            this.exitMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitApplicationToolStripMenuItem});
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(37, 20);
            this.exitMenu.Text = "Exit";
            // 
            // exitApplicationToolStripMenuItem
            // 
            this.exitApplicationToolStripMenuItem.Name = "exitApplicationToolStripMenuItem";
            this.exitApplicationToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.exitApplicationToolStripMenuItem.Text = "Exit Application";
            this.exitApplicationToolStripMenuItem.Click += new System.EventHandler(this.exitApplicationToolStripMenuItem_Click_1);
            // 
            // panel
            // 
            this.panel.Controls.Add(this.commonActionsLabel);
            this.panel.Controls.Add(this.registrationLabel);
            this.panel.Controls.Add(this.addCoursesLabel);
            this.panel.Controls.Add(this.addFacultyLabel);
            this.panel.Controls.Add(this.addStudentsLabel);
            this.panel.Controls.Add(this.registerClassesIcon);
            this.panel.Controls.Add(this.addFacultyIcon);
            this.panel.Controls.Add(this.addCoursesIcon);
            this.panel.Controls.Add(this.addStudentsIcon);
            this.panel.Location = new System.Drawing.Point(0, 27);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(1183, 592);
            this.panel.TabIndex = 1;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
            // 
            // commonActionsLabel
            // 
            this.commonActionsLabel.AutoSize = true;
            this.commonActionsLabel.BackColor = System.Drawing.Color.Transparent;
            this.commonActionsLabel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.commonActionsLabel.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commonActionsLabel.Location = new System.Drawing.Point(394, 43);
            this.commonActionsLabel.Name = "commonActionsLabel";
            this.commonActionsLabel.Size = new System.Drawing.Size(378, 55);
            this.commonActionsLabel.TabIndex = 8;
            this.commonActionsLabel.Text = "Common Actions";
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Location = new System.Drawing.Point(974, 437);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(91, 13);
            this.registrationLabel.TabIndex = 7;
            this.registrationLabel.Text = "Class Registration";
            // 
            // addCoursesLabel
            // 
            this.addCoursesLabel.AutoSize = true;
            this.addCoursesLabel.Location = new System.Drawing.Point(686, 437);
            this.addCoursesLabel.Name = "addCoursesLabel";
            this.addCoursesLabel.Size = new System.Drawing.Size(62, 13);
            this.addCoursesLabel.TabIndex = 6;
            this.addCoursesLabel.Text = "Add Course";
            // 
            // addFacultyLabel
            // 
            this.addFacultyLabel.AutoSize = true;
            this.addFacultyLabel.Location = new System.Drawing.Point(401, 437);
            this.addFacultyLabel.Name = "addFacultyLabel";
            this.addFacultyLabel.Size = new System.Drawing.Size(63, 13);
            this.addFacultyLabel.TabIndex = 5;
            this.addFacultyLabel.Text = "Add Faculty";
            // 
            // addStudentsLabel
            // 
            this.addStudentsLabel.AutoSize = true;
            this.addStudentsLabel.Location = new System.Drawing.Point(90, 437);
            this.addStudentsLabel.Name = "addStudentsLabel";
            this.addStudentsLabel.Size = new System.Drawing.Size(71, 13);
            this.addStudentsLabel.TabIndex = 4;
            this.addStudentsLabel.Text = "Add Students";
            // 
            // registerClassesIcon
            // 
            this.registerClassesIcon.BackColor = System.Drawing.Color.White;
            this.registerClassesIcon.BackgroundImage = global::TeamD.Properties.Resources.ARegister;
            this.registerClassesIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.registerClassesIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.registerClassesIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.registerClassesIcon.Location = new System.Drawing.Point(885, 149);
            this.registerClassesIcon.Name = "registerClassesIcon";
            this.registerClassesIcon.Size = new System.Drawing.Size(285, 285);
            this.registerClassesIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.registerClassesIcon.TabIndex = 3;
            this.registerClassesIcon.TabStop = false;
            this.registerClassesIcon.Click += new System.EventHandler(this.registration_Click);
            // 
            // addFacultyIcon
            // 
            this.addFacultyIcon.BackColor = System.Drawing.Color.White;
            this.addFacultyIcon.BackgroundImage = global::TeamD.Properties.Resources.ATeacher;
            this.addFacultyIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.addFacultyIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.addFacultyIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addFacultyIcon.Location = new System.Drawing.Point(303, 149);
            this.addFacultyIcon.Name = "addFacultyIcon";
            this.addFacultyIcon.Size = new System.Drawing.Size(285, 285);
            this.addFacultyIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.addFacultyIcon.TabIndex = 2;
            this.addFacultyIcon.TabStop = false;
            this.addFacultyIcon.Click += new System.EventHandler(this.addFaculty_Click);
            // 
            // addCoursesIcon
            // 
            this.addCoursesIcon.BackColor = System.Drawing.Color.White;
            this.addCoursesIcon.BackgroundImage = global::TeamD.Properties.Resources.ACourse;
            this.addCoursesIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.addCoursesIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.addCoursesIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addCoursesIcon.Location = new System.Drawing.Point(594, 149);
            this.addCoursesIcon.Name = "addCoursesIcon";
            this.addCoursesIcon.Size = new System.Drawing.Size(285, 285);
            this.addCoursesIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.addCoursesIcon.TabIndex = 1;
            this.addCoursesIcon.TabStop = false;
            this.addCoursesIcon.Click += new System.EventHandler(this.addCourses_Click);
            // 
            // addStudentsIcon
            // 
            this.addStudentsIcon.BackColor = System.Drawing.Color.White;
            this.addStudentsIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.addStudentsIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.addStudentsIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addStudentsIcon.Image = global::TeamD.Properties.Resources.AStudent;
            this.addStudentsIcon.ImageLocation = "";
            this.addStudentsIcon.Location = new System.Drawing.Point(12, 149);
            this.addStudentsIcon.Name = "addStudentsIcon";
            this.addStudentsIcon.Size = new System.Drawing.Size(285, 285);
            this.addStudentsIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.addStudentsIcon.TabIndex = 0;
            this.addStudentsIcon.TabStop = false;
            this.addStudentsIcon.Click += new System.EventHandler(this.addStudents_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.backToApplicationToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 618);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.mainMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mainMenu;
            this.Name = "Main";
            this.Text = "TeamD School Application";
            this.Load += new System.EventHandler(this.Main_Load);
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.registerClassesIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addFacultyIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addCoursesIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addStudentsIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem students;
        private System.Windows.Forms.ToolStripMenuItem faculty;
        private System.Windows.Forms.ToolStripMenuItem courses;
        private System.Windows.Forms.ToolStripMenuItem registration;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.ToolStripMenuItem printReport;
        private System.Windows.Forms.ToolStripMenuItem registerCourses;
        private System.Windows.Forms.ToolStripMenuItem addStudents;
        private System.Windows.Forms.ToolStripMenuItem addFaculty;
        private System.Windows.Forms.ToolStripMenuItem addCourses;
        private System.Windows.Forms.PictureBox addStudentsIcon;
        private System.Windows.Forms.PictureBox registerClassesIcon;
        private System.Windows.Forms.PictureBox addFacultyIcon;
        private System.Windows.Forms.PictureBox addCoursesIcon;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label addCoursesLabel;
        private System.Windows.Forms.Label addFacultyLabel;
        private System.Windows.Forms.Label addStudentsLabel;
        private System.Windows.Forms.Label commonActionsLabel;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.ToolStripMenuItem exitApplicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
    }
}

