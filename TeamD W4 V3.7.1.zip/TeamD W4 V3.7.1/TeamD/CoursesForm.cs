﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TeamD
{
    public partial class CoursesForm : Form
    {
        public CoursesForm()
        {

            InitializeComponent();

            txtCourseStart.MinDate = DateTime.Today.AddDays(-7);
            txtCourseStart.MaxDate = DateTime.Today.AddDays(20000);
            txtCourseEnd.MinDate = DateTime.Today.AddDays(-7);
            txtCourseEnd.MaxDate = DateTime.Today.AddDays(20000);
            //this piece limits the calender to only be chosen 30 days prior, and out by 2000 days on both spectrums.

        }

        public void add(String studName, String studID, String coursenm, String coursedes, String starttime, String endtime, String courseloc,String coursecred,String facID)
        {
            String[] row = { studName,studID,coursenm,coursedes,starttime,endtime,courseloc,coursecred,facID };
            ListViewItem item = new ListViewItem(row);
            couList.Items.Add(item);
        }
        private void btnAddCourses_Click_1(object sender, EventArgs e)
        {
            add(stuName.Text,stuIDn.Text,coursen.Text,coursed.Text,txtCourseStart.Text,txtCourseEnd.Text,txtCourseLoc.Text,txtCourseCred.Text,txtFactultyID.Text);

            stuName.Text = "";
            stuIDn.Text = "";
            coursen.Text = "";
            coursed.Text = "";
            txtCourseStart.Text = "";
            txtCourseEnd.Text = "";
            txtCourseLoc.Text = "";
            txtCourseCred.Text = "";
            txtFactultyID.Text = "";

            ClearTextBoxes();
            MessageBox.Show("Thank you for your submission!");

                        
/**
                string coursesInfo = stuName.Text + "," + stuIDn.Text + "," + txtCourseStart.Text + "," + txtCourseEnd.Text + "," + txtCourseLoc.Text + "," + txtCourseCred.Text +
                                "," + txtFactultyID.Text + "\r\n";
                FileWorker fileWorker = new FileWorker();
                fileWorker.SaveFile("Courses.txt", coursesInfo);
                ClearTextBoxes();
                MessageBox.Show("Thank you for your submission!");
                //using string command, the allocated code following gets saved into a flat text document that can be pulled from using dividers.
                //following the save of the information, ClearTextBoxes will then erase the information and give the confirmation.
**/  
            
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void CoursesForm_Load(object sender, EventArgs e)
        {
            couList.View = View.Details;
            couList.FullRowSelect = true;
            couList.Columns.Add("Student Name", 110);
            couList.Columns.Add("Student ID#", 110);
            couList.Columns.Add("Course Number", 110);
            couList.Columns.Add("Course Description", 110);
            couList.Columns.Add("Start Date", 110);
            couList.Columns.Add("End Date", 110);
            couList.Columns.Add("Location", 110);
            couList.Columns.Add("Number of Credits", 110);
            couList.Columns.Add("Faculty ID#", 110);

            couList.Items.Clear();

            StreamReader reader = new StreamReader(@"Courses.txt");
            while (!reader.EndOfStream)
            {
                reader.ReadLine();

            }
        }
    }
}
