﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 1/30/2017
//  Description : This is the form and the controls for Student addition
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;
using System.Diagnostics;

namespace TeamD
{
    public partial class StudentsForm : Form
    {
        char[] delimiterChars = { ' ', ',', '.', ':', '\t' };
        public StudentsForm()
        {
            InitializeComponent();
            
        }
        public class CsvRow : List<string>
        {
            public string LineText { get; set; }
        }
        
        // Click event that adds the entered student information to the Students.txt file
        public void add(String firstname,String lastname, String id, String addr, String phone, String email, String degree)
        {
            String[] row = { firstname, lastname, id, addr, phone, email, degree };
            ListViewItem item = new ListViewItem(row);
            stuList.Items.Add(item);
        }
        public void addStudentsButton_Click(object sender, EventArgs e)
        {
            add(firstName.Text, lastName.Text, studentId.Text, address.Text, phoneNumber.Text, email.Text, degreeProgram.Text);

            firstName.Text = "";
            lastName.Text = "";
            studentId.Text = "";
            address.Text = "";
            phoneNumber.Text = "";
            email.Text = "";
            degreeProgram.Text = "";

            ClearTextBoxes();
            MessageBox.Show("Thank you for your submission!");

/**
                        string studentInfo = firstName.Text + "," + lastName.Text + "," + studentId.Text + "," + address.Text + "," + phoneNumber.Text + "," + email.Text +
                       "," + degreeProgram.Text + "\r\n";
                        FileWorker fileWorker = new FileWorker();
                        fileWorker.SaveFile("Students.txt", studentInfo);
                        ClearTextBoxes();
                        MessageBox.Show("Thank you for your submission!");
**/
        }

        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void StudentsForm_Load(object sender, EventArgs e)
        {
            stuList.View = View.Details;
            stuList.FullRowSelect = true;
            stuList.Columns.Add("First Name", 110);
            stuList.Columns.Add("Last Name", 110);
            stuList.Columns.Add("Student ID#", 110);
            stuList.Columns.Add("Address", 110);
            stuList.Columns.Add("Phone Number", 110);
            stuList.Columns.Add("Email", 110);
            stuList.Columns.Add("Degree", 110);

            stuList.Items.Clear();

            StreamReader reader = new StreamReader(@"Students.txt");
            while(!reader.EndOfStream)
            {
                reader.ReadLine();

            }
        }
          
    }
}
