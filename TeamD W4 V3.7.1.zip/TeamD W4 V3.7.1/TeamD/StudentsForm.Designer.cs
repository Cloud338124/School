﻿namespace TeamD
{
    partial class StudentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.facultyTitle = new System.Windows.Forms.Label();
            this.phoneNumber = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.studentId = new System.Windows.Forms.TextBox();
            this.lastName = new System.Windows.Forms.TextBox();
            this.firstName = new System.Windows.Forms.TextBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.studentIdLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.addStudentsButton = new System.Windows.Forms.Button();
            this.email = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.degreeLabel = new System.Windows.Forms.Label();
            this.degreeProgram = new System.Windows.Forms.ComboBox();
            this.stuList = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // facultyTitle
            // 
            this.facultyTitle.AutoSize = true;
            this.facultyTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.facultyTitle.Location = new System.Drawing.Point(4, 3);
            this.facultyTitle.Name = "facultyTitle";
            this.facultyTitle.Size = new System.Drawing.Size(130, 31);
            this.facultyTitle.TabIndex = 0;
            this.facultyTitle.Text = "Students";
            // 
            // phoneNumber
            // 
            this.phoneNumber.Location = new System.Drawing.Point(112, 145);
            this.phoneNumber.Name = "phoneNumber";
            this.phoneNumber.Size = new System.Drawing.Size(400, 20);
            this.phoneNumber.TabIndex = 5;
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(112, 119);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(400, 20);
            this.address.TabIndex = 4;
            // 
            // studentId
            // 
            this.studentId.Location = new System.Drawing.Point(112, 93);
            this.studentId.Name = "studentId";
            this.studentId.Size = new System.Drawing.Size(400, 20);
            this.studentId.TabIndex = 3;
            // 
            // lastName
            // 
            this.lastName.Location = new System.Drawing.Point(112, 67);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(400, 20);
            this.lastName.TabIndex = 2;
            // 
            // firstName
            // 
            this.firstName.Location = new System.Drawing.Point(112, 41);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(400, 20);
            this.firstName.TabIndex = 1;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(12, 148);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneNumberLabel.TabIndex = 0;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(12, 122);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(45, 13);
            this.addressLabel.TabIndex = 0;
            this.addressLabel.Text = "Address";
            // 
            // studentIdLabel
            // 
            this.studentIdLabel.AutoSize = true;
            this.studentIdLabel.Location = new System.Drawing.Point(13, 96);
            this.studentIdLabel.Name = "studentIdLabel";
            this.studentIdLabel.Size = new System.Drawing.Size(58, 13);
            this.studentIdLabel.TabIndex = 0;
            this.studentIdLabel.Text = "Student ID";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(12, 70);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 0;
            this.lastNameLabel.Text = "Last Name";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(12, 44);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name";
            // 
            // addStudentsButton
            // 
            this.addStudentsButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addStudentsButton.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addStudentsButton.Location = new System.Drawing.Point(12, 562);
            this.addStudentsButton.Name = "addStudentsButton";
            this.addStudentsButton.Size = new System.Drawing.Size(75, 23);
            this.addStudentsButton.TabIndex = 8;
            this.addStudentsButton.Text = "Add";
            this.addStudentsButton.UseVisualStyleBackColor = true;
            this.addStudentsButton.Click += new System.EventHandler(this.addStudentsButton_Click);
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(112, 171);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(400, 20);
            this.email.TabIndex = 6;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(12, 174);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(73, 13);
            this.emailLabel.TabIndex = 0;
            this.emailLabel.Text = "Email Address";
            // 
            // degreeLabel
            // 
            this.degreeLabel.AutoSize = true;
            this.degreeLabel.Location = new System.Drawing.Point(12, 200);
            this.degreeLabel.Name = "degreeLabel";
            this.degreeLabel.Size = new System.Drawing.Size(84, 13);
            this.degreeLabel.TabIndex = 0;
            this.degreeLabel.Text = "Degree Program";
            // 
            // degreeProgram
            // 
            this.degreeProgram.FormattingEnabled = true;
            this.degreeProgram.Items.AddRange(new object[] {
            "Accounting & Finance",
            "Business & Management",
            "Criminal Justice",
            "General Electives",
            "Information Technology",
            "Nursing & Health",
            "Social Science",
            "Teacher Education"});
            this.degreeProgram.Location = new System.Drawing.Point(112, 197);
            this.degreeProgram.Name = "degreeProgram";
            this.degreeProgram.Size = new System.Drawing.Size(400, 21);
            this.degreeProgram.TabIndex = 7;
            // 
            // stuList
            // 
            this.stuList.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.stuList.AutoArrange = false;
            this.stuList.BackColor = System.Drawing.Color.White;
            this.stuList.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.stuList.Location = new System.Drawing.Point(518, 41);
            this.stuList.Name = "stuList";
            this.stuList.Size = new System.Drawing.Size(660, 544);
            this.stuList.TabIndex = 9;
            this.stuList.UseCompatibleStateImageBehavior = false;
            this.stuList.View = System.Windows.Forms.View.Details;
            // 
            // StudentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1199, 597);
            this.Controls.Add(this.stuList);
            this.Controls.Add(this.degreeProgram);
            this.Controls.Add(this.degreeLabel);
            this.Controls.Add(this.email);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.addStudentsButton);
            this.Controls.Add(this.phoneNumber);
            this.Controls.Add(this.address);
            this.Controls.Add(this.studentId);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.phoneNumberLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.studentIdLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.facultyTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentsForm";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.StudentsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label facultyTitle;
        private System.Windows.Forms.TextBox phoneNumber;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.TextBox studentId;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label studentIdLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Button addStudentsButton;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label degreeLabel;
        private System.Windows.Forms.ComboBox degreeProgram;
        public System.Windows.Forms.ListView stuList;
    }
}