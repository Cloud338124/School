﻿namespace TeamD
{
    partial class FacultyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.facultyTitle = new System.Windows.Forms.Label();
            this.addFacultyButton = new System.Windows.Forms.Button();
            this.className = new System.Windows.Forms.TextBox();
            this.classLabel = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.phoneNumber = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.facultyId = new System.Windows.Forms.TextBox();
            this.lastName = new System.Windows.Forms.TextBox();
            this.firstName = new System.Windows.Forms.TextBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.facultyIdLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.facList = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // facultyTitle
            // 
            this.facultyTitle.AutoSize = true;
            this.facultyTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.facultyTitle.Location = new System.Drawing.Point(4, 3);
            this.facultyTitle.Name = "facultyTitle";
            this.facultyTitle.Size = new System.Drawing.Size(110, 31);
            this.facultyTitle.TabIndex = 0;
            this.facultyTitle.Text = "Faculty";
            // 
            // addFacultyButton
            // 
            this.addFacultyButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addFacultyButton.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addFacultyButton.Location = new System.Drawing.Point(12, 562);
            this.addFacultyButton.Name = "addFacultyButton";
            this.addFacultyButton.Size = new System.Drawing.Size(75, 23);
            this.addFacultyButton.TabIndex = 8;
            this.addFacultyButton.Text = "Add";
            this.addFacultyButton.UseVisualStyleBackColor = true;
            this.addFacultyButton.Click += new System.EventHandler(this.addFacultyButton_Click);
            // 
            // className
            // 
            this.className.Location = new System.Drawing.Point(112, 197);
            this.className.Name = "className";
            this.className.Size = new System.Drawing.Size(400, 20);
            this.className.TabIndex = 7;
            // 
            // classLabel
            // 
            this.classLabel.AutoSize = true;
            this.classLabel.Location = new System.Drawing.Point(12, 200);
            this.classLabel.Name = "classLabel";
            this.classLabel.Size = new System.Drawing.Size(63, 13);
            this.classLabel.TabIndex = 0;
            this.classLabel.Text = "Class Name";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(112, 171);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(400, 20);
            this.email.TabIndex = 6;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(12, 174);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(73, 13);
            this.emailLabel.TabIndex = 0;
            this.emailLabel.Text = "Email Address";
            // 
            // phoneNumber
            // 
            this.phoneNumber.Location = new System.Drawing.Point(112, 145);
            this.phoneNumber.Name = "phoneNumber";
            this.phoneNumber.Size = new System.Drawing.Size(400, 20);
            this.phoneNumber.TabIndex = 5;
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(112, 119);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(400, 20);
            this.address.TabIndex = 4;
            // 
            // facultyId
            // 
            this.facultyId.Location = new System.Drawing.Point(112, 93);
            this.facultyId.Name = "facultyId";
            this.facultyId.Size = new System.Drawing.Size(400, 20);
            this.facultyId.TabIndex = 3;
            // 
            // lastName
            // 
            this.lastName.Location = new System.Drawing.Point(112, 67);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(400, 20);
            this.lastName.TabIndex = 2;
            // 
            // firstName
            // 
            this.firstName.Location = new System.Drawing.Point(112, 41);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(400, 20);
            this.firstName.TabIndex = 1;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(12, 148);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneNumberLabel.TabIndex = 0;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(12, 122);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(45, 13);
            this.addressLabel.TabIndex = 0;
            this.addressLabel.Text = "Address";
            // 
            // facultyIdLabel
            // 
            this.facultyIdLabel.AutoSize = true;
            this.facultyIdLabel.Location = new System.Drawing.Point(13, 96);
            this.facultyIdLabel.Name = "facultyIdLabel";
            this.facultyIdLabel.Size = new System.Drawing.Size(55, 13);
            this.facultyIdLabel.TabIndex = 0;
            this.facultyIdLabel.Text = "Faculty ID";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(12, 70);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 0;
            this.lastNameLabel.Text = "Last Name";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(12, 44);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name";
            // 
            // facList
            // 
            this.facList.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.facList.AutoArrange = false;
            this.facList.BackColor = System.Drawing.Color.White;
            this.facList.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.facList.Location = new System.Drawing.Point(518, 41);
            this.facList.Name = "facList";
            this.facList.Size = new System.Drawing.Size(660, 544);
            this.facList.TabIndex = 10;
            this.facList.UseCompatibleStateImageBehavior = false;
            this.facList.View = System.Windows.Forms.View.Details;
            // 
            // FacultyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 597);
            this.Controls.Add(this.facList);
            this.Controls.Add(this.className);
            this.Controls.Add(this.classLabel);
            this.Controls.Add(this.email);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.phoneNumber);
            this.Controls.Add(this.address);
            this.Controls.Add(this.facultyId);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.phoneNumberLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.facultyIdLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.addFacultyButton);
            this.Controls.Add(this.facultyTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FacultyForm";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.FacultyForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label facultyTitle;
        private System.Windows.Forms.Button addFacultyButton;
        private System.Windows.Forms.TextBox className;
        private System.Windows.Forms.Label classLabel;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.TextBox phoneNumber;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.TextBox facultyId;
        private System.Windows.Forms.TextBox lastName;
        private System.Windows.Forms.TextBox firstName;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label facultyIdLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        public System.Windows.Forms.ListView facList;
    }
}