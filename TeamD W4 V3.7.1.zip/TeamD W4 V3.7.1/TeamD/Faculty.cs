﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 2/12/2017
//  Description : This is the class used for the creation of faculty objects
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamD
{
    class Faculty
    {
        public string firstName { set; get; }
        public string lastName { set; get; }
        public int facultyId { set; get; }
        public string address { set; get; }
        public string phoneNumber { set; get; }
        public string emailAddress { set; get; }
        public string className { set; get; }
    }
}
