﻿/////////////////////
//  Author : Kevin Hicks
//  Date : 1/30/2017
//  Description : This application demonstrates the for, while, and do-while loops in C#
////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loops
{
    public partial class loops : Form
    {
        // Declares starting number, ending number, and creates variables for the output and a counter
        public static int startNum = 10;
        public static int endNum = 100;
        public string output;
        public int count;

        public loops()
        {
            InitializeComponent();
        }

        // Method that runs a for loop as long as the counter is less than or equal to the endning number from the starting number to the ending number
        // and outputs every third number
        private void forLoop()
        {
            // Sets the output to the starting number
            output = startNum.ToString();

            for (count = startNum; count <= endNum; count++)
            {
                // Checks if the counter minus the starting number is divisible by 3 and greater than the starting number, then if it is, adds the counter 
                // to the output string. By zeroing out the starting number by subtracting it from the counter, every third number becomes divisible by three
                if (((count - startNum) % 3 == 0) && count > startNum)
                {
                    output = output + "," + count.ToString();
                }

                // Ouputs the output string to the corresponding label in the form
                forOut.Text = output;
            }
        }

        // Method that runs a while loop as long as the counter is less than or equal to the endning number from the starting number to the ending number
        // and outputs every third number
        private void whileLoop()
        {
            // Sets the output and counter back to the starting number
            output = startNum.ToString();
            count = startNum;

            while (count <= endNum)
            {
                // Checks if the counter minus the starting number is divisible by 3 and greater than the starting number, then if it is, adds the counter 
                // to the output string
                if (((count - startNum) % 3 == 0) && count > startNum)
                {
                    output = output + "," + count.ToString();
                }
                count++;

                // Ouputs the output string to the corresponding label in the form
                whileOut.Text = output;
            }
        }

        // Method that runs a do-while loop as long as the counter is less than or equal to the endning number from the starting number to the ending number 
        // and outputs every third number
        private void doWhileLoop()
        {
            // Sets the output and counter back to the starting number
            output = startNum.ToString();
            count = startNum;
            do
            {
                // Checks if the counter minus the starting number is divisible by 3 and greater than the starting number, then if it is, adds the counter 
                // to the output string
                if (((count - startNum) % 3 == 0) && count > startNum)
                {
                    output = output + "," + count.ToString();
                }
                count++;

                // Ouputs the output string to the corresponding label in the form
                doWhileOut.Text = output;
            }
            while (count <= endNum);
        }

        // Button event that calls the loop methods
        private void startLoops_Click(object sender, EventArgs e)
        {
            forLoop();            
            whileLoop();
            doWhileLoop();
        }
    }
}
