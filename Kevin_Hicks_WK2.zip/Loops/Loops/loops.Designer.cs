﻿namespace Loops
{
    partial class loops
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.forLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.forOut = new System.Windows.Forms.Label();
            this.doWhileOut = new System.Windows.Forms.Label();
            this.whileOut = new System.Windows.Forms.Label();
            this.doWhileLabel = new System.Windows.Forms.Label();
            this.startLoops = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // forLabel
            // 
            this.forLabel.AutoSize = true;
            this.forLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forLabel.Location = new System.Drawing.Point(12, 9);
            this.forLabel.Name = "forLabel";
            this.forLabel.Size = new System.Drawing.Size(183, 25);
            this.forLabel.TabIndex = 0;
            this.forLabel.Text = "For Loop Output";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "While Loop Output";
            // 
            // forOut
            // 
            this.forOut.AutoSize = true;
            this.forOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forOut.ForeColor = System.Drawing.Color.Red;
            this.forOut.Location = new System.Drawing.Point(12, 44);
            this.forOut.Name = "forOut";
            this.forOut.Size = new System.Drawing.Size(0, 20);
            this.forOut.TabIndex = 2;
            // 
            // doWhileOut
            // 
            this.doWhileOut.AutoSize = true;
            this.doWhileOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doWhileOut.ForeColor = System.Drawing.Color.Red;
            this.doWhileOut.Location = new System.Drawing.Point(13, 174);
            this.doWhileOut.Name = "doWhileOut";
            this.doWhileOut.Size = new System.Drawing.Size(0, 20);
            this.doWhileOut.TabIndex = 3;
            // 
            // whileOut
            // 
            this.whileOut.AutoSize = true;
            this.whileOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.whileOut.ForeColor = System.Drawing.Color.Red;
            this.whileOut.Location = new System.Drawing.Point(13, 109);
            this.whileOut.Name = "whileOut";
            this.whileOut.Size = new System.Drawing.Size(0, 20);
            this.whileOut.TabIndex = 4;
            // 
            // doWhileLabel
            // 
            this.doWhileLabel.AutoSize = true;
            this.doWhileLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doWhileLabel.Location = new System.Drawing.Point(11, 139);
            this.doWhileLabel.Name = "doWhileLabel";
            this.doWhileLabel.Size = new System.Drawing.Size(244, 25);
            this.doWhileLabel.TabIndex = 5;
            this.doWhileLabel.Text = "Do-While Loop Output";
            // 
            // startLoops
            // 
            this.startLoops.Location = new System.Drawing.Point(17, 207);
            this.startLoops.Name = "startLoops";
            this.startLoops.Size = new System.Drawing.Size(101, 23);
            this.startLoops.TabIndex = 6;
            this.startLoops.Text = "Start the loops!";
            this.startLoops.UseVisualStyleBackColor = true;
            this.startLoops.Click += new System.EventHandler(this.startLoops_Click);
            // 
            // loops
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 254);
            this.Controls.Add(this.startLoops);
            this.Controls.Add(this.doWhileLabel);
            this.Controls.Add(this.whileOut);
            this.Controls.Add(this.doWhileOut);
            this.Controls.Add(this.forOut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.forLabel);
            this.Name = "loops";
            this.Text = "Fruit Loops";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label forLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label forOut;
        private System.Windows.Forms.Label doWhileOut;
        private System.Windows.Forms.Label whileOut;
        private System.Windows.Forms.Label doWhileLabel;
        private System.Windows.Forms.Button startLoops;
    }
}

