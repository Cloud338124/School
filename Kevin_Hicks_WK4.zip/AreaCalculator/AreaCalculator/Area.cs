﻿//////////////////////////////////
//  Author : Kevin Hicks
//  Date : 2/13/17
//  Description : This application calculates the area and perimeter of a quadrilateral given the length and width in inches. It displays the area in inches, feet
//  centimeters, and meters.
//////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaCalculator
{
    public partial class Area : Form
    {
        public Area()
        {
            InitializeComponent();
        }
        // Click event that starts the calculation and conversion
        private void calculateAreaButton_Click(object sender, EventArgs e)
        {
            // Try -catch block to catch the format and out of range errors
            try
            {
                // If statement that checks the value of the length and width field, and if they are not a non-zero positive number, 
                // throws an ArgumentOutOfRangeException
                if (double.Parse(length.Text) <= 0 || double.Parse(width.Text) <= 0)
                {
                    throw new ArgumentOutOfRangeException();
                }
                // Doubles to calculate the base area and perimeter in inches
                double areaInInches = double.Parse(length.Text) * double.Parse(width.Text);
                double perimeterInInches = (double.Parse(length.Text) * 2) + (double.Parse(width.Text) * 2);
                
                // Sets the perimeter ouput and makes it visible
                perimeterInches.Text = Math.Round(perimeterInInches, 2).ToString() + " inches";
                perimeterInches.Visible = true;

                // Instantiates the AreaConverter class to handle the conversion of the area in inches to other measurements
                AreaConverter areaConverter = new AreaConverter();

                // Displays the base area in inches, rounded to 2 decimal places
                areaSquareInches.Text = Math.Round(areaInInches, 2).ToString() + " in\x00b2";
                areaSquareInches.Visible = true;
                // Displays the area in feet by calling the conversion method, rounded to 2 decimal places
                areaSquareFeet.Text = Math.Round(areaConverter.toFeet(areaInInches), 2).ToString() + " ft\x00b2";
                areaSquareFeet.Visible = true;
                // Displays the area in meters, rounded to 2 decimal places
                areaSquareMeters.Text = Math.Round(areaConverter.toMeters(areaInInches), 2).ToString() + " m\x00b2";
                areaSquareMeters.Visible = true;
                // Displays the base area in centimeters, rounded to 2 decimal places
                areaSquareCentimeters.Text = Math.Round(areaConverter.toCentimeters(areaInInches), 2).ToString() + " cm\x00b2";
                areaSquareCentimeters.Visible = true;
            }
            // Catches the error when the fomrat entered is non numerical
            catch (FormatException)
            {
                // Clears both text boxes and displays an error with instructions on how to proceed
                length.Clear();
                width.Clear();
                MessageBox.Show("Please only enter numerical values in proper decimal format", "Non-Numeric Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // Catches the ArgumentOutOfRangeException that was thrown above if the number is negative or zero
            catch(ArgumentOutOfRangeException)
            {
                // Clears both text boxes and displays an error with instructions on how to proceed
                length.Clear();
                width.Clear();
                MessageBox.Show("The length and width must be positive non-zero numbers", "Non-Psotive Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }    
    }
}
