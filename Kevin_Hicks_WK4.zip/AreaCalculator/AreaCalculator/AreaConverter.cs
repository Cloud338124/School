﻿//////////////////////////////////
//  Author : Kevin Hicks
//  Date : 2/13/17
//  Description : This class is responsible for converting the area in inches to other formats and returning the result
//////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaCalculator
{
    class AreaConverter
    {
        // Method that calculates and returns the area in feet when given the area in inches
        public double toFeet(double areaInInches)
        {
            double areaInFeet = areaInInches * 0.00694444;
            return areaInFeet;
        }
        // Method that calculates and returns the area in meters when given the area in inches
        public double toMeters(double areaInInches)
        {
            double areaInMeters = areaInInches * 0.00064516;
            return areaInMeters;
        }
        // Method that calculates and returns the area in centimeters when given the area in inches
        public double toCentimeters(double areaInInches)
        {
            double areaInCentimeters = areaInInches * 6.4516;
            return areaInCentimeters;
        }
    }
}
