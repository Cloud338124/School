﻿namespace AreaCalculator
{
    partial class Area
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lengthLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.length = new System.Windows.Forms.TextBox();
            this.width = new System.Windows.Forms.TextBox();
            this.areaFeetLabel = new System.Windows.Forms.Label();
            this.areaMetersLabel = new System.Windows.Forms.Label();
            this.areaCentimetersLabel = new System.Windows.Forms.Label();
            this.areaSquareFeet = new System.Windows.Forms.Label();
            this.areaSquareMeters = new System.Windows.Forms.Label();
            this.areaSquareCentimeters = new System.Windows.Forms.Label();
            this.calculateAreaButton = new System.Windows.Forms.Button();
            this.areaSquareInches = new System.Windows.Forms.Label();
            this.areaSquareInchesLabel = new System.Windows.Forms.Label();
            this.perimeterInches = new System.Windows.Forms.Label();
            this.perimeterInchesLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lengthLabel.Location = new System.Drawing.Point(13, 13);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(141, 20);
            this.lengthLabel.TabIndex = 0;
            this.lengthLabel.Text = "Length in inches";
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.widthLabel.Location = new System.Drawing.Point(12, 45);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(131, 20);
            this.widthLabel.TabIndex = 1;
            this.widthLabel.Text = "Width in inches";
            // 
            // length
            // 
            this.length.Location = new System.Drawing.Point(160, 15);
            this.length.Name = "length";
            this.length.Size = new System.Drawing.Size(100, 20);
            this.length.TabIndex = 2;
            // 
            // width
            // 
            this.width.Location = new System.Drawing.Point(160, 47);
            this.width.Name = "width";
            this.width.Size = new System.Drawing.Size(100, 20);
            this.width.TabIndex = 3;
            // 
            // areaFeetLabel
            // 
            this.areaFeetLabel.AutoSize = true;
            this.areaFeetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaFeetLabel.Location = new System.Drawing.Point(14, 210);
            this.areaFeetLabel.Name = "areaFeetLabel";
            this.areaFeetLabel.Size = new System.Drawing.Size(171, 20);
            this.areaFeetLabel.TabIndex = 4;
            this.areaFeetLabel.Text = "Area in Square Feet";
            // 
            // areaMetersLabel
            // 
            this.areaMetersLabel.AutoSize = true;
            this.areaMetersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaMetersLabel.Location = new System.Drawing.Point(14, 275);
            this.areaMetersLabel.Name = "areaMetersLabel";
            this.areaMetersLabel.Size = new System.Drawing.Size(189, 20);
            this.areaMetersLabel.TabIndex = 5;
            this.areaMetersLabel.Text = "Area in Square Meters";
            // 
            // areaCentimetersLabel
            // 
            this.areaCentimetersLabel.AutoSize = true;
            this.areaCentimetersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaCentimetersLabel.Location = new System.Drawing.Point(14, 340);
            this.areaCentimetersLabel.Name = "areaCentimetersLabel";
            this.areaCentimetersLabel.Size = new System.Drawing.Size(231, 20);
            this.areaCentimetersLabel.TabIndex = 6;
            this.areaCentimetersLabel.Text = "Area in Square Centimeters";
            // 
            // areaSquareFeet
            // 
            this.areaSquareFeet.AutoSize = true;
            this.areaSquareFeet.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaSquareFeet.ForeColor = System.Drawing.Color.ForestGreen;
            this.areaSquareFeet.Location = new System.Drawing.Point(13, 240);
            this.areaSquareFeet.Name = "areaSquareFeet";
            this.areaSquareFeet.Size = new System.Drawing.Size(181, 25);
            this.areaSquareFeet.TabIndex = 7;
            this.areaSquareFeet.Text = "areaSquareFeet";
            this.areaSquareFeet.Visible = false;
            // 
            // areaSquareMeters
            // 
            this.areaSquareMeters.AutoSize = true;
            this.areaSquareMeters.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaSquareMeters.ForeColor = System.Drawing.Color.ForestGreen;
            this.areaSquareMeters.Location = new System.Drawing.Point(13, 305);
            this.areaSquareMeters.Name = "areaSquareMeters";
            this.areaSquareMeters.Size = new System.Drawing.Size(206, 25);
            this.areaSquareMeters.TabIndex = 8;
            this.areaSquareMeters.Text = "areaSquareMeters";
            this.areaSquareMeters.Visible = false;
            // 
            // areaSquareCentimeters
            // 
            this.areaSquareCentimeters.AutoSize = true;
            this.areaSquareCentimeters.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaSquareCentimeters.ForeColor = System.Drawing.Color.ForestGreen;
            this.areaSquareCentimeters.Location = new System.Drawing.Point(13, 370);
            this.areaSquareCentimeters.Name = "areaSquareCentimeters";
            this.areaSquareCentimeters.Size = new System.Drawing.Size(260, 25);
            this.areaSquareCentimeters.TabIndex = 9;
            this.areaSquareCentimeters.Text = "areaSquareCentimeters";
            this.areaSquareCentimeters.Visible = false;
            // 
            // calculateAreaButton
            // 
            this.calculateAreaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateAreaButton.Location = new System.Drawing.Point(266, 45);
            this.calculateAreaButton.Name = "calculateAreaButton";
            this.calculateAreaButton.Size = new System.Drawing.Size(81, 23);
            this.calculateAreaButton.TabIndex = 10;
            this.calculateAreaButton.Text = "Calculate";
            this.calculateAreaButton.UseVisualStyleBackColor = true;
            this.calculateAreaButton.Click += new System.EventHandler(this.calculateAreaButton_Click);
            // 
            // areaSquareInches
            // 
            this.areaSquareInches.AutoSize = true;
            this.areaSquareInches.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaSquareInches.ForeColor = System.Drawing.Color.ForestGreen;
            this.areaSquareInches.Location = new System.Drawing.Point(13, 175);
            this.areaSquareInches.Name = "areaSquareInches";
            this.areaSquareInches.Size = new System.Drawing.Size(203, 25);
            this.areaSquareInches.TabIndex = 12;
            this.areaSquareInches.Text = "areaSquareInches";
            this.areaSquareInches.Visible = false;
            // 
            // areaSquareInchesLabel
            // 
            this.areaSquareInchesLabel.AutoSize = true;
            this.areaSquareInchesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.areaSquareInchesLabel.Location = new System.Drawing.Point(14, 145);
            this.areaSquareInchesLabel.Name = "areaSquareInchesLabel";
            this.areaSquareInchesLabel.Size = new System.Drawing.Size(188, 20);
            this.areaSquareInchesLabel.TabIndex = 11;
            this.areaSquareInchesLabel.Text = "Area in Square Inches";
            // 
            // perimeterInches
            // 
            this.perimeterInches.AutoSize = true;
            this.perimeterInches.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perimeterInches.ForeColor = System.Drawing.Color.ForestGreen;
            this.perimeterInches.Location = new System.Drawing.Point(13, 110);
            this.perimeterInches.Name = "perimeterInches";
            this.perimeterInches.Size = new System.Drawing.Size(180, 25);
            this.perimeterInches.TabIndex = 14;
            this.perimeterInches.Text = "perimeterInches";
            this.perimeterInches.Visible = false;
            // 
            // perimeterInchesLabel
            // 
            this.perimeterInchesLabel.AutoSize = true;
            this.perimeterInchesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perimeterInchesLabel.Location = new System.Drawing.Point(14, 80);
            this.perimeterInchesLabel.Name = "perimeterInchesLabel";
            this.perimeterInchesLabel.Size = new System.Drawing.Size(164, 20);
            this.perimeterInchesLabel.TabIndex = 13;
            this.perimeterInchesLabel.Text = "Perimeter in Inches";
            // 
            // Area
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 419);
            this.Controls.Add(this.perimeterInches);
            this.Controls.Add(this.perimeterInchesLabel);
            this.Controls.Add(this.areaSquareInches);
            this.Controls.Add(this.areaSquareInchesLabel);
            this.Controls.Add(this.calculateAreaButton);
            this.Controls.Add(this.areaSquareCentimeters);
            this.Controls.Add(this.areaSquareMeters);
            this.Controls.Add(this.areaSquareFeet);
            this.Controls.Add(this.areaCentimetersLabel);
            this.Controls.Add(this.areaMetersLabel);
            this.Controls.Add(this.areaFeetLabel);
            this.Controls.Add(this.width);
            this.Controls.Add(this.length);
            this.Controls.Add(this.widthLabel);
            this.Controls.Add(this.lengthLabel);
            this.Name = "Area";
            this.Text = "Area Calculator";            
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.TextBox length;
        private System.Windows.Forms.TextBox width;
        private System.Windows.Forms.Label areaFeetLabel;
        private System.Windows.Forms.Label areaMetersLabel;
        private System.Windows.Forms.Label areaCentimetersLabel;
        private System.Windows.Forms.Label areaSquareFeet;
        private System.Windows.Forms.Label areaSquareMeters;
        private System.Windows.Forms.Label areaSquareCentimeters;
        private System.Windows.Forms.Button calculateAreaButton;
        private System.Windows.Forms.Label areaSquareInches;
        private System.Windows.Forms.Label areaSquareInchesLabel;
        private System.Windows.Forms.Label perimeterInches;
        private System.Windows.Forms.Label perimeterInchesLabel;
    }
}

