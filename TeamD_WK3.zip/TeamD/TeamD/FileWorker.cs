﻿///////////////////////
//  Author : Kevin Hicks, Robert Ford, Amber Capehart, Jerry Merten
//  Date : 2/5/2017
//  Description : Class for working with files. Reads file from txt file in CSV format to array. Writes from array to txt files in CSV format
///////////////////////
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamD
{
    class FileWorker
    {
        // Method for reading files that are in CSV format and returning an array that contains the lines of the file as values
        public string[] ReadFile(string filePath)
        {          
            StreamReader file = new StreamReader(filePath);           
            string line;
            string output = "";
            string[] array = null;
            try
            {
                while ((line = file.ReadLine()) != null)
                {
                    output = output + line + ";";               
                }
            }
            catch
            {

            }
            output.TrimEnd(';');
            array = output.Split(';');    
            return array;
        }
        // Writes a string to a new line in a file. The string should be in CSV format
        public void SaveFile(string filePath, string line)
        {            
            File.AppendAllText(filePath, line);
        }
    }
}
