﻿namespace TeamD
{
    partial class Courses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFactultyID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCourseCred = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCourseLoc = new System.Windows.Forms.TextBox();
            this.txtCourseEnd = new System.Windows.Forms.TextBox();
            this.txtCourseStart = new System.Windows.Forms.TextBox();
            this.txtCourseDesc = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lable3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lable1 = new System.Windows.Forms.Label();
            this.lblCourses = new System.Windows.Forms.Label();
            this.txtCourseNum = new System.Windows.Forms.TextBox();
            this.btnAddCourses = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtFactultyID
            // 
            this.txtFactultyID.Location = new System.Drawing.Point(116, 257);
            this.txtFactultyID.Name = "txtFactultyID";
            this.txtFactultyID.Size = new System.Drawing.Size(100, 20);
            this.txtFactultyID.TabIndex = 43;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 42;
            this.label7.Text = "Faculty ID#:";
            // 
            // txtCourseCred
            // 
            this.txtCourseCred.Location = new System.Drawing.Point(116, 222);
            this.txtCourseCred.Name = "txtCourseCred";
            this.txtCourseCred.Size = new System.Drawing.Size(100, 20);
            this.txtCourseCred.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 40;
            this.label6.Text = "Course Credits:";
            // 
            // txtCourseLoc
            // 
            this.txtCourseLoc.Location = new System.Drawing.Point(116, 186);
            this.txtCourseLoc.Name = "txtCourseLoc";
            this.txtCourseLoc.Size = new System.Drawing.Size(100, 20);
            this.txtCourseLoc.TabIndex = 39;
            // 
            // txtCourseEnd
            // 
            this.txtCourseEnd.Location = new System.Drawing.Point(116, 150);
            this.txtCourseEnd.Name = "txtCourseEnd";
            this.txtCourseEnd.Size = new System.Drawing.Size(100, 20);
            this.txtCourseEnd.TabIndex = 38;
            // 
            // txtCourseStart
            // 
            this.txtCourseStart.Location = new System.Drawing.Point(116, 114);
            this.txtCourseStart.Name = "txtCourseStart";
            this.txtCourseStart.Size = new System.Drawing.Size(100, 20);
            this.txtCourseStart.TabIndex = 37;
            // 
            // txtCourseDesc
            // 
            this.txtCourseDesc.Location = new System.Drawing.Point(116, 78);
            this.txtCourseDesc.Name = "txtCourseDesc";
            this.txtCourseDesc.Size = new System.Drawing.Size(100, 20);
            this.txtCourseDesc.TabIndex = 36;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Course Location:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "End Date:";
            // 
            // lable3
            // 
            this.lable3.AutoSize = true;
            this.lable3.Location = new System.Drawing.Point(12, 117);
            this.lable3.Name = "lable3";
            this.lable3.Size = new System.Drawing.Size(58, 13);
            this.lable3.TabIndex = 32;
            this.lable3.Text = "Start Date:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Course Description:";
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Location = new System.Drawing.Point(12, 44);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(83, 13);
            this.lable1.TabIndex = 30;
            this.lable1.Text = "Course Number:";
            // 
            // lblCourses
            // 
            this.lblCourses.AutoSize = true;
            this.lblCourses.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourses.Location = new System.Drawing.Point(4, 3);
            this.lblCourses.Name = "lblCourses";
            this.lblCourses.Size = new System.Drawing.Size(237, 31);
            this.lblCourses.TabIndex = 29;
            this.lblCourses.Text = "Course Selection";
            // 
            // txtCourseNum
            // 
            this.txtCourseNum.Location = new System.Drawing.Point(116, 42);
            this.txtCourseNum.Name = "txtCourseNum";
            this.txtCourseNum.Size = new System.Drawing.Size(100, 20);
            this.txtCourseNum.TabIndex = 44;
            // 
            // btnAddCourses
            // 
            this.btnAddCourses.Location = new System.Drawing.Point(10, 523);
            this.btnAddCourses.Name = "btnAddCourses";
            this.btnAddCourses.Size = new System.Drawing.Size(75, 23);
            this.btnAddCourses.TabIndex = 45;
            this.btnAddCourses.Text = "Add";
            this.btnAddCourses.UseVisualStyleBackColor = true;
            this.btnAddCourses.Click += new System.EventHandler(this.btnAddCourses_Click);
            // 
            // Courses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1183, 558);
            this.Controls.Add(this.btnAddCourses);
            this.Controls.Add(this.txtCourseNum);
            this.Controls.Add(this.txtFactultyID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCourseCred);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCourseLoc);
            this.Controls.Add(this.txtCourseEnd);
            this.Controls.Add(this.txtCourseStart);
            this.Controls.Add(this.txtCourseDesc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lable3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lable1);
            this.Controls.Add(this.lblCourses);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Courses";
            this.Text = "Courses";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFactultyID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCourseCred;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCourseLoc;
        private System.Windows.Forms.TextBox txtCourseEnd;
        private System.Windows.Forms.TextBox txtCourseStart;
        private System.Windows.Forms.TextBox txtCourseDesc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lable3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label lblCourses;
        private System.Windows.Forms.TextBox txtCourseNum;
        private System.Windows.Forms.Button btnAddCourses;
    }
}