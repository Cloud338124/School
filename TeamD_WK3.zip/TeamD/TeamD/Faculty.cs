﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 1/30/2017
//  Description : This is the form and the controls for Faculty addition
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamD
{
    public partial class Faculty : Form
    {
        public Faculty()
        {
            InitializeComponent();
        }
        Main main = new Main();
        // Click event that adds the entered faculty information to the Faculty.txt file
        private void addFacultyButton_Click(object sender, EventArgs e)
        {
            string facultyInfo = firstName.Text + "," + lastName.Text + "," + facultyId.Text + "," + address.Text + "," + phoneNumber.Text + "," + email.Text +
                "," + className.Text + "\r\n";
            FileWorker fileWorker = new FileWorker();
            fileWorker.SaveFile("Faculty.txt", facultyInfo);
            ClearTextBoxes();
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }
    }
}
