/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcprogram;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kevin
 */
public class JDBCProgram {
    static String action;
    static String check;
    static int index;
    static Scanner input;
    static DatabaseConnection db  =  new DatabaseConnection ();
    static ResultSet rs = null;
    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
             
        
        userInterface(); 
        
        // infinite while loop to keep the app running until the user is finished
        while (true){
            /*
            *   Switch statement to validate input from the user and execute the
            *   command that the user has chosen
            */
            switch (check) {
                case "A":
                case "a":
                    addAnimal();
                    userInterface();
                    break;
                case "D":
                case "d":
                    deleteAnimal();
                    userInterface();
                    break;
                case "E":
                case "e":
                    editAnimal();
                    userInterface();
                    break;
                case "S":
                case "s":            
                    selectAnimal();
                    userInterface();
                    break;
                case "x":
                case "X":
                    System.out.println("Exiting Application");
            {
                try {
                    db.con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(JDBCProgram.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                    System.exit(0);
                default:
                    System.out.println("Invalid Selection. Choose A, D, E, S, or X ");
                    userInterface();
                    break;
            }
        }
    }
    /*
    *   Creates the main UI that allows user to navigate the application
    *
    */
        private static void userInterface()
    {
        System.out.println("(A) - Add Animal \t (D) - Delete Animal \t (E) - Edit Animal \t (S) - Select Animal \t (X) - Exit ");
        System.out.print("Select an Action : ");
        input = new Scanner(System.in);
        action = input.next();
        check=action;
    }
    private static void addAnimal(){
        System.out.println("Feature in progress");
    }
    private static void deleteAnimal(){
        System.out.println("Feature in progress");
    }
    private static void editAnimal(){
        System.out.println("Feature in progress");
    }
    // used to select and animal
    private static void selectAnimal(){         
        printAnimalNames(); 
        System.out.print("Choose an Animal by using the animals ID: ");
        input = new Scanner(System.in);
        int selection = input.nextInt();        
        printAnimalCharacteristics(selection);        
    }
    // Queries the DB to get all of the animals names and IDs and prints them for the user to choose from
    private static void printAnimalNames(){
        try {            
            PreparedStatement animalNames = db.con.prepareStatement("SELECT id,name FROM animals");
            rs = animalNames.executeQuery();
            System.out.println("Animal ID \t Animal Name");
            
            while (rs.next()){
                System.out.println(rs.getString("ID")+" \t\t " + rs.getString("NAME"));
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(JDBCProgram.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // Prints the characteristic of one of the Animals in the array list
    private static void printAnimalCharacteristics(int index){
        try {
            PreparedStatement animalChars = db.con.prepareStatement("SELECT * FROM animals WHERE id= ?");
            animalChars.setInt(1,index);
            rs = animalChars.executeQuery();
            while(rs.next()){
                System.out.println("\nID : " + rs.getString("ID"));
                System.out.println("Name : " + rs.getString("NAME"));
                System.out.println("Color : " + rs.getString("COLOR"));
                System.out.println("Height : " + rs.getString("HEIGHT")+" feet");
                System.out.println("Weight : " + rs.getString("WEIGHT")+" lbs\n");
            }
        } catch (SQLException ex) {
            Logger.getLogger(JDBCProgram.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

    

