/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcprogram;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kevin
 */
public class DatabaseConnection {
    /*
    *   Sets the DB url, username, and password in private fields so that they cannot
    *   be called from any other class. Also sets the connection variable to a null
    *   value upon execution to use later in the application. Creates the DB if
    *   it is not present.
    */
    private final String url = "jdbc:derby://localhost:1527/Animals; create=true"; 
    private final String user = "username"; 
    private final String pwd = "password";
    Connection con = null;

        public DatabaseConnection(){
           // creates the database connection using the above credentials
            try {
                con = DriverManager.getConnection(url, user, pwd);
            } catch (SQLException ex) {
                Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
            /*
            *   Tests to see if the Animals databas has an animals table in it.
            *   If not, it will be created and populated with the preselected
            *   data.
            */
            try {
                DatabaseMetaData md = con.getMetaData();
                ResultSet table = md.getTables(null,null,"ANIMALS",new String[] {"TABLE"});
                if (table.next()){
                    // Do nothing                    
                }else{
                    con.setAutoCommit(false);
                    System.out.println("Creating tables...");
                    try {
                        PreparedStatement create = con.prepareStatement(""
                                + "CREATE TABLE Animals (id int NOT NULL GENERATED ALWAYS AS "
                                + "IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY ,name varchar(20), "
                                + "color varchar(10), height varchar(30), weight varchar(30))");
                        create.execute();
                        PreparedStatement insert = con.prepareStatement("INSERT INTO ANIMALS (name,color,height,weight)VALUES('Cat','Black','1','15')");
                        insert.execute();
                        insert = con.prepareStatement("INSERT INTO ANIMALS (name,color,height,weight)VALUES('Lion','Beige','3.9','420')");
                        insert.execute();
                        insert = con.prepareStatement("INSERT INTO ANIMALS (name,color,height,weight)VALUES('Dog','Brown','2','15')");
                        insert.execute();
                        insert = con.prepareStatement("INSERT INTO ANIMALS (name,color,height,weight)VALUES('Zebra','Striped','3','1000')");
                        insert.execute();
                        insert = con.prepareStatement("INSERT INTO ANIMALS (name,color,height,weight)VALUES('Tiger','Striped','4','800')");
                        insert.execute();
                        insert = con.prepareStatement("INSERT INTO ANIMALS (name,color,height,weight)VALUES('Bear','Brown','3.3','1400')");
                        insert.execute();
                        con.commit();
                        System.out.println("Tables Created");
                    } catch (SQLException ex) {
                        Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
                    } 
                }
            } catch (SQLException ex) {
                Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
            }
       }
    
}
