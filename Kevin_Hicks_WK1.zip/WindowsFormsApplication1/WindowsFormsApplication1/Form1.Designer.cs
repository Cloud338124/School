﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioFifteen = new System.Windows.Forms.RadioButton();
            this.radioTwenty = new System.Windows.Forms.RadioButton();
            this.billAmount = new System.Windows.Forms.TextBox();
            this.instructBill = new System.Windows.Forms.Label();
            this.instructTip = new System.Windows.Forms.Label();
            this.totalText = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.fifteenPercent = new System.Windows.Forms.Label();
            this.twentyPercent = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // radioFifteen
            // 
            this.radioFifteen.AutoSize = true;
            this.radioFifteen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioFifteen.Location = new System.Drawing.Point(12, 88);
            this.radioFifteen.Name = "radioFifteen";
            this.radioFifteen.Size = new System.Drawing.Size(82, 20);
            this.radioFifteen.TabIndex = 0;
            this.radioFifteen.TabStop = true;
            this.radioFifteen.Text = "15% Tip";
            this.radioFifteen.UseVisualStyleBackColor = true;
            this.radioFifteen.CheckedChanged += new System.EventHandler(this.radioFifteen_CheckedChanged);
            // 
            // radioTwenty
            // 
            this.radioTwenty.AutoSize = true;
            this.radioTwenty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioTwenty.Location = new System.Drawing.Point(12, 112);
            this.radioTwenty.Name = "radioTwenty";
            this.radioTwenty.Size = new System.Drawing.Size(82, 20);
            this.radioTwenty.TabIndex = 1;
            this.radioTwenty.TabStop = true;
            this.radioTwenty.Text = "20% Tip";
            this.radioTwenty.UseVisualStyleBackColor = true;
            // 
            // billAmount
            // 
            this.billAmount.Location = new System.Drawing.Point(143, 17);
            this.billAmount.Name = "billAmount";
            this.billAmount.Size = new System.Drawing.Size(100, 20);
            this.billAmount.TabIndex = 2;
            this.billAmount.TextChanged += new System.EventHandler(this.billAmount_TextChanged);
            // 
            // instructBill
            // 
            this.instructBill.AutoSize = true;
            this.instructBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructBill.Location = new System.Drawing.Point(12, 19);
            this.instructBill.Name = "instructBill";
            this.instructBill.Size = new System.Drawing.Size(125, 16);
            this.instructBill.TabIndex = 3;
            this.instructBill.Text = "Enter Bill Amount";
            // 
            // instructTip
            // 
            this.instructTip.AutoSize = true;
            this.instructTip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructTip.Location = new System.Drawing.Point(9, 65);
            this.instructTip.Name = "instructTip";
            this.instructTip.Size = new System.Drawing.Size(143, 16);
            this.instructTip.TabIndex = 4;
            this.instructTip.Text = "Choose Tip Amount";
            // 
            // totalText
            // 
            this.totalText.AutoSize = true;
            this.totalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalText.Location = new System.Drawing.Point(9, 135);
            this.totalText.Name = "totalText";
            this.totalText.Size = new System.Drawing.Size(197, 16);
            this.totalText.TabIndex = 5;
            this.totalText.Text = "Your Total With Tip is $0.00";
            // 
            // resetButton
            // 
            this.resetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetButton.Location = new System.Drawing.Point(121, 161);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(123, 33);
            this.resetButton.TabIndex = 6;
            this.resetButton.Text = "Reset Form";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // fifteenPercent
            // 
            this.fifteenPercent.AutoSize = true;
            this.fifteenPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fifteenPercent.Location = new System.Drawing.Point(100, 90);
            this.fifteenPercent.Name = "fifteenPercent";
            this.fifteenPercent.Size = new System.Drawing.Size(44, 16);
            this.fifteenPercent.TabIndex = 7;
            this.fifteenPercent.Text = "$0.00";
            // 
            // twentyPercent
            // 
            this.twentyPercent.AutoSize = true;
            this.twentyPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twentyPercent.Location = new System.Drawing.Point(100, 114);
            this.twentyPercent.Name = "twentyPercent";
            this.twentyPercent.Size = new System.Drawing.Size(44, 16);
            this.twentyPercent.TabIndex = 8;
            this.twentyPercent.Text = "$0.00";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(254, 206);
            this.Controls.Add(this.twentyPercent);
            this.Controls.Add(this.fifteenPercent);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.totalText);
            this.Controls.Add(this.instructTip);
            this.Controls.Add(this.instructBill);
            this.Controls.Add(this.billAmount);
            this.Controls.Add(this.radioTwenty);
            this.Controls.Add(this.radioFifteen);
            this.Name = "Form1";
            this.Text = "Tip Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioFifteen;
        private System.Windows.Forms.RadioButton radioTwenty;
        private System.Windows.Forms.TextBox billAmount;
        private System.Windows.Forms.Label instructBill;
        private System.Windows.Forms.Label instructTip;
        private System.Windows.Forms.Label totalText;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label fifteenPercent;
        private System.Windows.Forms.Label twentyPercent;
    }
}

