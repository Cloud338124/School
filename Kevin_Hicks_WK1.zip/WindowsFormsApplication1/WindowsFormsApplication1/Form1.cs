﻿//
// Author : Kevin Hicks
// Date : 1/23/2017
// Description : Tip calculator that calculates a 15% and 20% tip on any inputted amount.
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        // Initialize the tip percentage multiplier variable with the default value of 115%. The calculation will multiply the bill amount by this to give
        // 100% of the bill amount plus 15% of the bill amount to accurately calculate the tip
        private double tipPercent = 1.15;

        public Form1()
        {
            InitializeComponent();
        }
        // Changes the tipPercent variable based on which radio button is selected
        private void radioFifteen_CheckedChanged(object sender, EventArgs e)
        {
            if (radioFifteen.Checked == true)
            {
                tipPercent = 1.15;               
            }
            else
            {
                tipPercent = 1.20;
            }
            // Checks to see if the bill amount has been entered before trying to calculate the tip when the radio selection is changed.
            if (string.IsNullOrEmpty(billAmount.Text))
            {
                // Do Nothing
            }
            else
            {
                calculateTotal(double.Parse(billAmount.Text));
            }
                
        }
        // Attepmts to pass the input to the calculateTotal function as the user enters the bill amount
        private void billAmount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                calculateTotal(double.Parse(billAmount.Text));
            }
            catch
            {
                // Do Nothing
            }
        }
        // Calculates the total amount due and changes the display to show the total amount due. Also calculates the individual 
        // amounts for both tip amounts and displays them
        private void calculateTotal(double subTotal)
        {
            try
            {
                double total;
                fifteenPercent.Text=(subTotal * .15 ).ToString("C2");
                twentyPercent.Text = (subTotal * .20).ToString("C2");
                total = subTotal * tipPercent;
                totalText.Text = "Your Total With Tip is " + total.ToString("C2");
            }
            catch
            {
                // Do Nothing
            }
        }
        // Resets the form to its default state
        private void resetButton_Click(object sender, EventArgs e)
        {
            totalText.Text = "Your Total With Tip is $0.00";
            fifteenPercent.Text = "$0.00";
            twentyPercent.Text = "$0.00";
            billAmount.Clear();
            radioFifteen.Checked = true;
        }
    }
}
