/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concurrency;


/**
 *
 * @author Kevin
 */
public class Threader implements Runnable{
    /*  Overides and creates the run method for the runnable that
    *   calls the atomic mehtod
    */
    @Override
    public void run(){
        atomic();
    }
    /*  Counts from 0 to 10 and prints the count plus the thread name 
    *   for identification
    */
    public void atomic(){ 
        for(int i = 0; i<=10; i++){
            System.out.println(Thread.currentThread().getName() + " is running : Count " + i + " out of 10");
        }
    }
}
