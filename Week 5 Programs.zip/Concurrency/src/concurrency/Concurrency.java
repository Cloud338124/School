/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concurrency;


/**
 *
 * @author Kevin
 */
public class Concurrency {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Creates the runnable
        Threader t = new Threader();
        // Throws the runnable into 2 threads
        Thread thread1 = new Thread(t);        
        Thread thread2 = new Thread(t);
        // Names the threads
        thread1.setName("Dave");
        thread2.setName("Danny");
        //Starts both threads
        thread1.start();
        thread2.start();
        
    }
}
