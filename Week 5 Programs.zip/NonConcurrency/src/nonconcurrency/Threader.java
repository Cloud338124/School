/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nonconcurrency;

import java.util.concurrent.locks.*;


/**
 *
 * @author Kevin
 */
public class Threader implements Runnable{
    // Creates the lock used to lock the atomic mehtod
    Lock lock = new ReentrantLock();
    /*  Overides and creates the run method for the runnable that
    *   calls the atomic mehtod
    */
    @Override
    public void run(){
        /*  Locks the atomic method and sarounds the call in a try - finally
        *   block to ensure that the lock unlocks at the end of the thread
        */
        lock.lock();
        try{
            atomic();
        }
        finally{
            lock.unlock();
        }
    }
    /*  Counts from 0 to 10 and prints the count plus the thread name 
    *   for identification
    */
    public void atomic(){ 
        for(int i = 0; i<=10; i++){
            System.out.println(Thread.currentThread().getName() + " is running : Count " + i + " out of 10");
        }
    }
}
