﻿namespace TeamD
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.students = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.faculty = new System.Windows.Forms.ToolStripMenuItem();
            this.addFaculty = new System.Windows.Forms.ToolStripMenuItem();
            this.courses = new System.Windows.Forms.ToolStripMenuItem();
            this.addCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.registration = new System.Windows.Forms.ToolStripMenuItem();
            this.printReport = new System.Windows.Forms.ToolStripMenuItem();
            this.registerCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.panel = new System.Windows.Forms.Panel();
            this.commonActionsLabel = new System.Windows.Forms.Label();
            this.registrationLabel = new System.Windows.Forms.Label();
            this.addCoursesLabel = new System.Windows.Forms.Label();
            this.addFacultyLabel = new System.Windows.Forms.Label();
            this.addStudentsLabel = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.removeFaculty = new System.Windows.Forms.ToolStripMenuItem();
            this.editFaculty = new System.Windows.Forms.ToolStripMenuItem();
            this.removeCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.editCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.removeStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.editStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenu.SuspendLayout();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.students,
            this.faculty,
            this.courses,
            this.registration,
            this.exitMenu});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mainMenu.Size = new System.Drawing.Size(1199, 24);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "menuStrip1";
            // 
            // students
            // 
            this.students.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudents,
            this.removeStudents,
            this.editStudents});
            this.students.Name = "students";
            this.students.Size = new System.Drawing.Size(65, 20);
            this.students.Text = "Students";
            // 
            // addStudents
            // 
            this.addStudents.Name = "addStudents";
            this.addStudents.Size = new System.Drawing.Size(152, 22);
            this.addStudents.Text = "Add";
            this.addStudents.Click += new System.EventHandler(this.addStudents_Click);
            // 
            // faculty
            // 
            this.faculty.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addFaculty,
            this.removeFaculty,
            this.editFaculty});
            this.faculty.Name = "faculty";
            this.faculty.Size = new System.Drawing.Size(57, 20);
            this.faculty.Text = "Faculty";
            // 
            // addFaculty
            // 
            this.addFaculty.Name = "addFaculty";
            this.addFaculty.Size = new System.Drawing.Size(152, 22);
            this.addFaculty.Text = "Add";
            this.addFaculty.Click += new System.EventHandler(this.addFaculty_Click);
            // 
            // courses
            // 
            this.courses.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCourses,
            this.removeCourses,
            this.editCourses});
            this.courses.Name = "courses";
            this.courses.Size = new System.Drawing.Size(61, 20);
            this.courses.Text = "Courses";
            // 
            // addCourses
            // 
            this.addCourses.Name = "addCourses";
            this.addCourses.Size = new System.Drawing.Size(152, 22);
            this.addCourses.Text = "Add";
            this.addCourses.Click += new System.EventHandler(this.addCourses_Click);
            // 
            // registration
            // 
            this.registration.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printReport,
            this.registerCourses});
            this.registration.Name = "registration";
            this.registration.Size = new System.Drawing.Size(82, 20);
            this.registration.Text = "Registration";
            // 
            // printReport
            // 
            this.printReport.Name = "printReport";
            this.printReport.Size = new System.Drawing.Size(223, 22);
            this.printReport.Text = "Print Report";
            this.printReport.Click += new System.EventHandler(this.printReport_Click);
            // 
            // registerCourses
            // 
            this.registerCourses.Name = "registerCourses";
            this.registerCourses.Size = new System.Drawing.Size(223, 22);
            this.registerCourses.Text = "Manage Course Registration";
            this.registerCourses.Click += new System.EventHandler(this.registration_Click);
            // 
            // exitMenu
            // 
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(37, 20);
            this.exitMenu.Text = "Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // panel
            // 
            this.panel.Controls.Add(this.commonActionsLabel);
            this.panel.Controls.Add(this.registrationLabel);
            this.panel.Controls.Add(this.addCoursesLabel);
            this.panel.Controls.Add(this.addFacultyLabel);
            this.panel.Controls.Add(this.addStudentsLabel);
            this.panel.Controls.Add(this.pictureBox4);
            this.panel.Controls.Add(this.pictureBox3);
            this.panel.Controls.Add(this.pictureBox2);
            this.panel.Controls.Add(this.pictureBox1);
            this.panel.Location = new System.Drawing.Point(0, 27);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(1199, 597);
            this.panel.TabIndex = 1;
            // 
            // commonActionsLabel
            // 
            this.commonActionsLabel.AutoSize = true;
            this.commonActionsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commonActionsLabel.Location = new System.Drawing.Point(2, 38);
            this.commonActionsLabel.Name = "commonActionsLabel";
            this.commonActionsLabel.Size = new System.Drawing.Size(404, 55);
            this.commonActionsLabel.TabIndex = 8;
            this.commonActionsLabel.Text = "Common Actions";
            // 
            // registrationLabel
            // 
            this.registrationLabel.AutoSize = true;
            this.registrationLabel.Location = new System.Drawing.Point(983, 401);
            this.registrationLabel.Name = "registrationLabel";
            this.registrationLabel.Size = new System.Drawing.Size(85, 13);
            this.registrationLabel.TabIndex = 7;
            this.registrationLabel.Text = "Register Classes";
            // 
            // addCoursesLabel
            // 
            this.addCoursesLabel.AutoSize = true;
            this.addCoursesLabel.Location = new System.Drawing.Point(625, 401);
            this.addCoursesLabel.Name = "addCoursesLabel";
            this.addCoursesLabel.Size = new System.Drawing.Size(67, 13);
            this.addCoursesLabel.TabIndex = 6;
            this.addCoursesLabel.Text = "Add Courses";
            // 
            // addFacultyLabel
            // 
            this.addFacultyLabel.AutoSize = true;
            this.addFacultyLabel.Location = new System.Drawing.Point(348, 401);
            this.addFacultyLabel.Name = "addFacultyLabel";
            this.addFacultyLabel.Size = new System.Drawing.Size(63, 13);
            this.addFacultyLabel.TabIndex = 5;
            this.addFacultyLabel.Text = "Add Faculty";
            // 
            // addStudentsLabel
            // 
            this.addStudentsLabel.AutoSize = true;
            this.addStudentsLabel.Location = new System.Drawing.Point(94, 401);
            this.addStudentsLabel.Name = "addStudentsLabel";
            this.addStudentsLabel.Size = new System.Drawing.Size(71, 13);
            this.addStudentsLabel.TabIndex = 4;
            this.addStudentsLabel.Text = "Add Students";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Image = global::TeamD.Properties.Resources.Registration;
            this.pictureBox4.Location = new System.Drawing.Point(830, 149);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(348, 230);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.registration_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Image = global::TeamD.Properties.Resources.Faculty;
            this.pictureBox3.Location = new System.Drawing.Point(273, 149);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(231, 230);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.addFaculty_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = global::TeamD.Properties.Resources.Courses;
            this.pictureBox2.Location = new System.Drawing.Point(540, 149);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(253, 230);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.addCourses_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::TeamD.Properties.Resources.AddStudent;
            this.pictureBox1.Location = new System.Drawing.Point(12, 149);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 230);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.addStudents_Click);
            // 
            // removeFaculty
            // 
            this.removeFaculty.Name = "removeFaculty";
            this.removeFaculty.Size = new System.Drawing.Size(152, 22);
            this.removeFaculty.Text = "Remove";
            this.removeFaculty.Click += new System.EventHandler(this.removeFaculty_Click);
            // 
            // editFaculty
            // 
            this.editFaculty.Name = "editFaculty";
            this.editFaculty.Size = new System.Drawing.Size(152, 22);
            this.editFaculty.Text = "Edit";
            this.editFaculty.Click += new System.EventHandler(this.editFaculty_Click);
            // 
            // removeCourses
            // 
            this.removeCourses.Name = "removeCourses";
            this.removeCourses.Size = new System.Drawing.Size(152, 22);
            this.removeCourses.Text = "Remove";
            this.removeCourses.Click += new System.EventHandler(this.removeCourses_Click);
            // 
            // editCourses
            // 
            this.editCourses.Name = "editCourses";
            this.editCourses.Size = new System.Drawing.Size(152, 22);
            this.editCourses.Text = "Edit";
            this.editCourses.Click += new System.EventHandler(this.editCourses_Click);
            // 
            // removeStudents
            // 
            this.removeStudents.Name = "removeStudents";
            this.removeStudents.Size = new System.Drawing.Size(152, 22);
            this.removeStudents.Text = "Remove";
            this.removeStudents.Click += new System.EventHandler(this.removeStudents_Click);
            // 
            // editStudents
            // 
            this.editStudents.Name = "editStudents";
            this.editStudents.Size = new System.Drawing.Size(152, 22);
            this.editStudents.Text = "Edit";
            this.editStudents.Click += new System.EventHandler(this.editStudents_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 623);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.mainMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mainMenu;
            this.Name = "Main";
            this.Text = "TeamD School Application";
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem students;
        private System.Windows.Forms.ToolStripMenuItem faculty;
        private System.Windows.Forms.ToolStripMenuItem courses;
        private System.Windows.Forms.ToolStripMenuItem registration;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.ToolStripMenuItem printReport;
        private System.Windows.Forms.ToolStripMenuItem registerCourses;
        private System.Windows.Forms.ToolStripMenuItem addStudents;
        private System.Windows.Forms.ToolStripMenuItem addFaculty;
        private System.Windows.Forms.ToolStripMenuItem addCourses;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label registrationLabel;
        private System.Windows.Forms.Label addCoursesLabel;
        private System.Windows.Forms.Label addFacultyLabel;
        private System.Windows.Forms.Label addStudentsLabel;
        private System.Windows.Forms.Label commonActionsLabel;
        private System.Windows.Forms.ToolStripMenuItem removeStudents;
        private System.Windows.Forms.ToolStripMenuItem editStudents;
        private System.Windows.Forms.ToolStripMenuItem removeFaculty;
        private System.Windows.Forms.ToolStripMenuItem editFaculty;
        private System.Windows.Forms.ToolStripMenuItem removeCourses;
        private System.Windows.Forms.ToolStripMenuItem editCourses;
    }
}

