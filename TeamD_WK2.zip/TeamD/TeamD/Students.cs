﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 1/30/2017
//  Description : This application allows a school to manage students, faculty, courses, and the registration of the school while also 
//  allowing the reporting of current school registration
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamD
{
    public partial class Students : Form
    {
        public Students()
        {
            InitializeComponent();
        }
        // Click event that displays coming soon message
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Addition of Students Coming Soon");
        }

    }
}
