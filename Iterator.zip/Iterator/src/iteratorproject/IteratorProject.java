/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iteratorproject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Kevin
 */
public class IteratorProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Animal Array list to store the animal objects that we read from the file
        ArrayList<Animal> list = new ArrayList<>();
        
        String array[] = new String[4];
        
        // The name of the file to open.
        String fileName = "src\\iteratorproject\\animals.txt";

        // line refference
        String line = null;

        try {
            // FileReader reads text file.
            FileReader fileReader = 
                new FileReader(fileName);

            // BufferedReader to buffer the FileReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                // creates an array from the incoming string
                array = line.split(",");
                // uses the array to create an animal object and add it to the ArrayList
                Animal animal = new Animal(array[0],array[1],Double.parseDouble(array[2]),Double.parseDouble(array[3]));
                list.add(animal);
                
            }               
            
            //closes the files.            
            bufferedReader.close();         
        }
        // in case the file isn't present
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        // in case it can't read the file
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'"); 
        }
        
        // iterates throught the list of objects and creates a table of all of the animal objects
        System.out.println("Name\t\tColor\t\tHeight\t\tWeight");
        Iterator<Animal> it = list.iterator(); 
        while (it.hasNext()) {
            Animal animal = it.next();
            System.out.println(animal.animalName+"\t\t"+animal.animalColor+"\t\t"+animal.animalHeight+" ft\t\t"+animal.animalWeight+" lbs\t\t");
        }
    }
    
}
