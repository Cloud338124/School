﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 2/12/2017
//  Description : This is the class used for the creation of course objects
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamD
{
    class Course
    {
        public int courseNumber { set; get; }
        public string description { set; get; }
        public string startDate { set; get; }
        public string endDate { set; get; }
        public string courseLocation { set; get; }
        public int courseCredits { set; get; }
        public int factultyId { set; get; }
    }
}
