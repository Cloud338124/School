﻿////////////////////////////////
//
//  Authors : Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
//  Date : 2/12/2017
//  Description : This is the class used for the creation of student objects
//
///////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamD
{
    class Student
    {
        public string firstName { set; get; }
        public string lastName { set; get; }
        public int studentId { set; get; }
        public string address { set; get; }
        public string phoneNumber { set; get; }
        public string emailAddress { set; get; }
        public string degreeProgram { set; get; }
    }
}
