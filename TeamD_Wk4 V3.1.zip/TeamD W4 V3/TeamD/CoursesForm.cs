﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamD
{
    public partial class CoursesForm : Form
    {
        public CoursesForm()
        {
            InitializeComponent();
            
        }

        private void btnAddCourses_Click(object sender, EventArgs e)
        {
            string coursesInfo = txtCourseNum.Text + "," + txtCourseDesc.Text + "," + txtCourseStart.Text + "," + 
                txtCourseEnd.Text + "," + txtCourseLoc.Text + "," + txtCourseCred.Text +
                "," + txtFactultyID.Text + "\r\n";
            FileWorker fileWorker = new FileWorker();
            fileWorker.SaveFile("Courses.txt", coursesInfo);
            ClearTextBoxes();
            MessageBox.Show("Thank you for your submission!");
            //using string command, the allocated code following gets saved into a flat text document that can be pulled from using dividers.
            //following the save of the information, ClearTextBoxes will then erase the information and give the confirmation.
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }    
    }
}
