﻿/*Program: Student Course Registration
 * Version: 2.1
 * Author(s): Kevin Hicks, Robert Ford, Amber Capehart, and Jerry Merten
 * Class: POS/409 .NET II
 * Date: 02/06/2017
 * Program Description: This application allows a school to manage students, 
 * faculty, courses, and the registration of the school while 
 * also allowing the reporting of current school registration
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamD
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        // Exit Menu Button that closes the form with re-assurance
        private void exitMenu_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit the application?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        // BClick events for adding students
        public void addStudents_Click(object sender, EventArgs e)
        {
            // Clears the panel and loads the Student.cs form into it using the showForm method
           
            Form students = new StudentsForm();
            showForm(students,panel);
        }
        // End student click events

        // Click events for adding  faculty
        private void addFaculty_Click(object sender, EventArgs e)
        {
            // Clears the panel and loads the Faculty.cs form into it using the showForm method
            panel.Controls.Clear();
            Form faculty = new FacultyForm();
            showForm(faculty, panel);
        }

        // Click events for adding, removing, and editing courses
        private void addCourses_Click(object sender, EventArgs e)
        {
            // Clears the panel and loads the Courses.cs form into it using the showForm method
            panel.Controls.Clear();
            Form courses = new CoursesForm();
            showForm(courses, panel);
        } 

        // Click event for managing the registration of courses
        private void registration_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Class Registration Coming Soon");
        }

        //Click event for printing the registration report
        private void printReport_Click(object sender, EventArgs e)
        {
            //Opens print preview dialog box.
            printPreviewDialog1.ShowDialog();
        }  

        // Method for displaying the forms for the various functions in the panel within the Main.cs form
        public void showForm(Form childForm, Panel parent)
        {
            panel.Controls.Clear();
            

            childForm.TopLevel = false;
            childForm.Parent = parent;
            childForm.Dock = DockStyle.Fill;
            childForm.Show();
            parent.Parent = this;
            parent.Dock = DockStyle.Fill;
        }

        private void mainMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
